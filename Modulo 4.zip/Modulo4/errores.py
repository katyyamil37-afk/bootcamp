class EmailInvalidoError(Exception):
    pass
